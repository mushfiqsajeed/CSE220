//DO NOT MAKE ANY CHANGES HERE
class BSTNode {
    Integer elem;
    BSTNode left, right;

    public BSTNode(Integer elem) {
        this.elem = elem;
    }
}