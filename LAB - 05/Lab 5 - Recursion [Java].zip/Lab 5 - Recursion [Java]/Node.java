public class Node {
    int elem;
    Node next;

    public Node(int d) {
        elem = d;
        next = null;
    }
}