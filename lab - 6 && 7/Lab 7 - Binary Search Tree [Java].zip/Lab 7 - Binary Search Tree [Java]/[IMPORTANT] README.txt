DR JAVA IS NOT RECOMMENDED!
IT IS RECOMMENDED THAT YOU USE VSCODE/INTELLIJ for this and the future labs!!

Download all the files then GO THROUGH THE COMMENTS to figure out what to do.
You NEED to modify the Tester file for some of the tasks.
You NEED to complete the individual Task files.
Best of luck!
