DR JAVA IS NOT RECOMMENDED!
IT IS RECOMMENDED THAT YOU USE VSCODE/INTELLIJ for this and the future labs!!

You need to complete the individual Task java files and write your code there.
However, the testing needs to be done using BinaryTreeTester file. You don't need to modify the BinaryTreeTester file.
Go through the comments to figure out what to do.

Best of luck!
